package com.mycompany.question1;
public class Book extends LibrarySystem
{
    String author;
    public Book(String a,int b,String c)
    {
        title=a;
        itemID=b;
        author=c;
    }
    public void readBook(){System.out.println("Reading The Book");}
}
