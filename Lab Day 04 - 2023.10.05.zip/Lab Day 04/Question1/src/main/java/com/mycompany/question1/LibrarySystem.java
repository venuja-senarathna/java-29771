package com.mycompany.question1;
public class LibrarySystem 
{
    String title;
    int itemID;
    boolean isCheckedOut;
    public boolean checkOut()
    {
        isCheckedOut=true;
        return isCheckedOut;
    }
    public void returnitem(){isCheckedOut=false;}
}
