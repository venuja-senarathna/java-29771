package com.mycompany.question1;
public class ReferenceBook extends Book
{
    String edition;
    boolean isForReferenceOnly;
    public ReferenceBook(String a, int b, String c,String d,boolean e) 
    {
        super(a, b, c);
        edition=d;
        isForReferenceOnly=e;
    }
    public void displayinfo(){System.out.println("This Is A Reference Book");}
}
