package com.mycompany.question1;
public class DVD extends LibrarySystem
{
    String director;
    public DVD(String a,int b,String c)
    {
        title=a;
        itemID=b;
        director=c;
    }
    public void playDVD(){System.out.println("Playing The DVD");}
}
