package com.mycompany.question1;
public class Question1 
{
    public static void main(String[] args) 
    {
        Book b=new Book("Harry Poter",01,"J.K.Rowlings");
        b.checkOut();
        b.readBook();
        b.returnitem();
        System.out.println("Book Name - " + b.title);
        System.out.println("Book Author - " + b.author);
        System.out.println("Book ID - " + b.itemID);
        System.out.println("Book IsCheckOut - " + b.checkOut());
    }
}
