package com.mycompany.question2;
public class Question2 
{
    public static void main(String[] args) 
    {
        
    }
}
