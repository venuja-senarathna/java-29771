package com.mycompany.question2;

public class Character extends GameObject
{
    int health;
    public void attack(){
        System.out.println("Character " + name + "is attacking");
    }
    public void takeDamage(int damage)
    {
        health=health-damage;
    }
}
