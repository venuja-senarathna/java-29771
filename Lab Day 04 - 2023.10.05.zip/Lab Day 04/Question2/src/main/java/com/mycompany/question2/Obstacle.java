package com.mycompany.question2;
public class Obstacle extends GameObject
{
    double size;
    public void Break(){
            System.out.println("Obstacle " + name + "is broken");
}
}
