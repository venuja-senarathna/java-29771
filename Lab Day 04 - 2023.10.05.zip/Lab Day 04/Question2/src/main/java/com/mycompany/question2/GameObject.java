package com.mycompany.question2;
public class GameObject 
{
    String name;
    double positionX,positionY;
    public void moveTo(double x,double y){
        positionX=x;
        positionY=y;
    }
    public void render(){
        System.out.println("Rendering " + name + "at (" + positionX + "," + positionY + ")");
    }
}
