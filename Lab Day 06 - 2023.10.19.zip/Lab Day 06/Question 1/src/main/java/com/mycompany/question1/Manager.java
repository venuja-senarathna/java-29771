package com.mycompany.question1;
public class Manager extends Employee
{
    double bs,bo;
    public Manager(String a,String b,int c,double d,double e)
    {
        super(a,b,c);
        bs=d;
        bo=e;  
    }
    public double calculateSalary() 
    {
        return bs+bo;
    }
    public void displayEmployeeDetails() 
    {
        System.out.println("Name - " + name);
        System.out.println("Gender - " + gender);
        System.out.println("Age - " + age);
        System.out.println("Basic Salary - " +bs);
        System.out.println("Bonus - " +bo);
    }
    
}
