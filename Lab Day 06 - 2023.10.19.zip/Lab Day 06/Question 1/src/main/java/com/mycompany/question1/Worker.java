package com.mycompany.question1;
public class Worker extends Employee
{
    double hrate,nohw;
    public Worker(String a,String b,int c,double d,double e)
    {
        super(a,b,c);
        hrate=d;
        nohw=e;  
    }
    public double calculateSalary() 
    {
        return hrate*nohw;
    }
    public void displayEmployeeDetails() 
    {
        System.out.println("Name - " + name);
        System.out.println("Gender - " + gender);
        System.out.println("Age - " + age);
        System.out.println("Number Of Hours Worked - " +nohw);
        System.out.println("Hourly Rate - " +hrate);
    }
    
}
