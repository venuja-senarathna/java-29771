package com.mycompany.question1;
public class Question1 
{
    public static void main(String[] args) 
    {
        System.out.println("Manager");
        Manager m=new Manager("Dulan Nithila Liyanarachchi","Male",21,25000.00,15000.00);
        m.displayEmployeeDetails();
        System.out.println("Gross Salary - " + m.calculateSalary());
        System.out.println("\nWorker");
        Worker w=new Worker("Dulan Nithila Liyanarachchi","Male",21,1000.00,12);
        w.displayEmployeeDetails();
        System.out.println("Gross Salary - " + w.calculateSalary());
        System.out.println("\nSalesPerson");
        SalesPerson s=new SalesPerson("Dulan Nithila Liyanarachchi","Male",21,25000.00,15000.00,1000.00);
        s.displayEmployeeDetails();
        System.out.println("Gross Salary - " + s.calculateSalary());
    }
}
