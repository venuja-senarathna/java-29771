package com.mycompany.question1;
public abstract class Employee 
{
    String name,gender;
    int age;
    public Employee(String a,String b,int c)
    {
        name=a;
        gender=b;
        age=c;
    }
    public abstract double calculateSalary();
    public abstract void displayEmployeeDetails();
}
