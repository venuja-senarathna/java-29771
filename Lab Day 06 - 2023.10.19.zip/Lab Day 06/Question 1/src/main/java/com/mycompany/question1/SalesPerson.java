package com.mycompany.question1;
public class SalesPerson extends Manager
{
    double crate;
    public SalesPerson(String a,String b,int c,double d,double e,double f)
    {
        super(a,b,c,d,e);
        crate=f;
    }
    public double calculateSalary() 
    {
        return super.calculateSalary()*(1+crate);
    }
    public void displayEmployeeDetails() 
    {
        System.out.println("Name - " + name);
        System.out.println("Gender - " + gender);
        System.out.println("Age - " + age);
        System.out.println("Basic Salary - " +bs);
        System.out.println("Bonus - " +bo);
        System.out.println("Commision Rate - " + crate);
    }
}
