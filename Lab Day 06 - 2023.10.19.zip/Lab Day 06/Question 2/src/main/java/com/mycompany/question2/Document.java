package com.mycompany.question2;
public class Document implements Printable
{
    String d="This Is A Printed Document";
    public void print() 
    {
        System.out.println(d);
    }
    
}
