package com.mycompany.question2;
public class Question2 
{
    public static void main(String[] args) 
    {
        Document d=new Document();
        d.print();
        Photo p=new Photo();
        p.print();
    }
}
