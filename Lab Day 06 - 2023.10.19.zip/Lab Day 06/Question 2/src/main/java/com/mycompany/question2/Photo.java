package com.mycompany.question2;
public class Photo implements Printable
{
    String p="This Is A Printed Photo";
    public void print() 
    {
        System.out.println(p);
    }
    
}
