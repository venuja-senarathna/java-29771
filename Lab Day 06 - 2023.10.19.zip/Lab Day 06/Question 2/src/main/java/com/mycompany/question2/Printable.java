package com.mycompany.question2;
public interface Printable 
{
    public void print();
}
