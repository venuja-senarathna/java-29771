package com.mycompany.labday02;
public class Item 
{
    private int location;
    private String  description;
    public Item(int d,String e)
    {
        location=d;
        description=e;
    }
    public void setLocation(int location)
    {
        this.location=location;
    }
    public int getLocation()
    {
        return location;
    }
    public void setDescription(String description)
    {
        this.description=description;
    }
    public String getDescription()
    {
        return description;
    }
}
