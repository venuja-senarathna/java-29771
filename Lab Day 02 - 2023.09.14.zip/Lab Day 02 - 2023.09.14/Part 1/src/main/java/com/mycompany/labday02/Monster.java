package com.mycompany.labday02;
public class Monster extends Item
{
    public Monster(int d, String e) 
    {
        super(d, e);
    }
    
}
