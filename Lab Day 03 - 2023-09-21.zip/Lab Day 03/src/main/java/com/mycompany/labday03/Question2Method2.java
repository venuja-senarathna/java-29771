package com.mycompany.labday03;
public class Question2Method2 
{
    String name;
    int age;
    float salary;
    public Question2Method2(String a,int b,float c)
    {
        name=a;
        age=b;
        salary=c;
    }
    public String getname()
    {
        return name;
    }
    public int getage()
    {
        return age;
    }
    public float getsalary()
    {
        return salary;
    }
}
