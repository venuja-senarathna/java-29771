package com.mycompany.labday03;
import java.util.Scanner;
public class LabDay03 
{
    public static void main(String[] args) 
    {
        String a;
        float b;
        System.out.println("Question 1");
        Question1 q1=new Question1();
        Scanner sc1=new Scanner(System.in);
        System.out.println("Enter Your Name");
        a=sc1.nextLine();
        q1.setename(a);
        Scanner sc2=new Scanner(System.in);
        System.out.println("Enter Your Basic Salary");
        b=sc2.nextFloat();
        q1.setbsalary(b);
        System.out.println("");
        System.out.println("Name - "+q1.getename());
        System.out.println("Basic Salary - "+q1.getbsalary());
        Question1 q2=new Question1(b);
        q2.bamount(b);
        System.out.println("");
        System.out.println("Question 2");
        System.out.println("Method 1");
        String d="Dulan";
        int e=21;
        float f=25000;
        Question2Method1 e1m1=new Question2Method1();
        e1m1.setname(d);
        e1m1.setage(e);
        e1m1.setsalary(f);
        System.out.println("Name - "+e1m1.getname());
        System.out.println("Age - "+e1m1.getage());
        System.out.println("Salary - "+e1m1.getsalary());
        System.out.println("");
        System.out.println("Method 2");
        Question2Method2 e1m2=new Question2Method2(d,e,f);
        System.out.println("Name - "+e1m2.getname());
        System.out.println("Age - "+e1m2.getage());
        System.out.println("Salary - "+e1m2.getsalary());
        String g="Biscuit";
        float h=30;
        int i=20;
        System.out.println("");
        System.out.println("Question 3");
        Question3 j=new Question3(g,h,i);
        System.out.println("Name - "+j.getpname());
        System.out.println("Price - "+j.getprice());
        System.out.println("Qunatity In The Stock - "+j.getsquant());
    }
}
