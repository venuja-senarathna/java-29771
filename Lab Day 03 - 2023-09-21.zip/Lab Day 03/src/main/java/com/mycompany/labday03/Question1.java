package com.mycompany.labday03;
public class Question1 
{
    String ename;
    float bsalary,bonus;
    public Question1(){
        ename="null";
        bsalary=0;
        bonus=0;
    }
    public void setename(String en)
    {
        ename=en;
    }
    public void setbsalary(float bs)
    {
        bsalary=bs;
    }
    public String getename()
    {
        return ename;
    }
    public float getbsalary()
    {
       return bsalary;
    }
    public Question1(float bs)
    {
        bonus=(bs*20)/100;
        
    }
    public void bamount(float b){
        System.out.println("Bonus: "+bonus);
        float bamount=b+bonus;
        System.out.println("Bonus Amount: "+bamount);
    }
}
