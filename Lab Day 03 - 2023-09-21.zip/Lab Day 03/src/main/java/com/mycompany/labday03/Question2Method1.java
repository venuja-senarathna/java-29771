package com.mycompany.labday03;
public class Question2Method1 
{
    String name;
    int age;
    float salary;
    public void setname(String a)
    {
        name=a;
    }
    public void setage(int b)
    {
        age=b;
    }
    public void setsalary(float c)
    {
        salary=c;
    }
    public String getname()
    {
        return name;
    }
    public int getage()
    {
        return age;
    }
    public float getsalary()
    {
        return salary;
    }
}
