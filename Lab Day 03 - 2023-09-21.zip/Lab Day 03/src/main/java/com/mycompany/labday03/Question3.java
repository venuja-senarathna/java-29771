package com.mycompany.labday03;
public class Question3 
{
    String pname;
    float price;
    int squant=100,quant;
    public Question3(String a,float b,int c)
    {
        pname=a;
        price=b;
        quant=c;
    }
    public void sproduct()
    {
        dquant();
    }
    public void dquant()
    {
        squant=squant-quant;
    }
    public String getpname()
    {
        return pname;
    }
    public float getprice()
    {
        return price;
    }
    public int getsquant()
    {
        return squant;
    }
}

