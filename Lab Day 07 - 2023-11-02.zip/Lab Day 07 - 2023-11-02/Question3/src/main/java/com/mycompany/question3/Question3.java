package com.mycompany.question3;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Question3 
{
    public static void main(String[] args) 
    {
        final String doc="helloworld.txt";
        try
        {
            System.out.println("");
            File file = new File(doc);
            Scanner scanner = new Scanner(file);  
            while (scanner.hasNextLine()) 
            {
                
                System.out.println(scanner.nextLine());
            }
            scanner.close();
        } 
        catch (FileNotFoundException e)
        {
            System.out.println("File Doesn't Exists.");
            
        } 
    }
}
