package com.mycompany.question2;
import java.util.Scanner;
public class Question2 {

    public static void main(String[] args) {
        try 
        {
            int arr[]=new int[]{1,2,3,4,5};
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter The Index That You Want To Access - ");
            int i=sc.nextInt();
            System.out.println(arr[i]);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Index Is Greater Than The Array Size");
        }
    }
}
