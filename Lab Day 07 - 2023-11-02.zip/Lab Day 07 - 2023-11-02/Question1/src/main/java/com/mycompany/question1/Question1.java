package com.mycompany.question1;
import java.util.Scanner;
public class Question1 
{
    public static void main(String[] args)
    {
        try 
        {
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter First Integer(Y) - ");
            int y=sc.nextInt();
            System.out.print("Enter First Integer(Z) - ");
            int z=sc.nextInt();
            int x=y/z;
            System.out.println("X = Y/Z = "+y+"/"+z+" = "+x);
        }
        catch(ArithmeticException e)
        {
            System.out.println("Cannot Divide A Number By 0");
        }
    }
}
