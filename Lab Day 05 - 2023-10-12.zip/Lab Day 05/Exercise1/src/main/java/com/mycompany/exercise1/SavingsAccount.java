package com.mycompany.exercise1;
public class SavingsAccount extends BankAccount
{

    @Override
    public double calculateinstrest() 
    {
        double in;
        in=(balance*2)/100;
        balance=balance+in;
        return in;
    }
    
}
