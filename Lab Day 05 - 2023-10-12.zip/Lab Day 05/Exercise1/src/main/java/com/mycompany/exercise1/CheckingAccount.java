package com.mycompany.exercise1;
public class CheckingAccount extends BankAccount
{

    @Override
    public double calculateinstrest() 
    {
        double in;
        in=(balance*12)/100;
        balance=balance+in;
        return in;
    }
    
}
