package com.mycompany.exercise2;
public class Exercise2 
{
    public static void main(String[] args) 
    {
        Circle c=new Circle(10);
        System.out.println("\nCircle");
        System.out.println("Radius Of The Circle - " + c.radius);
        System.out.println("Area Of The Circle - " + c.calculateArea());
        System.out.println("Circumference(Perimeter) Of The Circle - " + c.calculatePerimeter());
        Rectangle r=new Rectangle(10,20);
        System.out.println("\nRectangle");
        System.out.println("Length Of The Rectangle - " + r.length);
        System.out.println("Width Of The Rectangle - " + r.width);
        System.out.println("Area Of The Rectangle - " + r.calculateArea());
        System.out.println("Perimeter Of The Rectangle - " + r.calculatePerimeter());
        Triangle t=new Triangle(10,20,8,12);
        System.out.println("\nTriangle");
        System.out.println("Base Length(Lenghth Of The Base Side) Of The Triangle - " + t.base);
        System.out.println("Side 2 Length Of The Triangle - " + t.l1);
        System.out.println("Side 3 Length Of The Triangle - " + t.l2);
        System.out.println("Area Of The Triangle - " + t.calculateArea());
        System.out.println("Perimeter Of The Triangle - " + t.calculatePerimeter());
    }
}
