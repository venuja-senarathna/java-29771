package com.mycompany.exercise2;
public class Rectangle implements Shape
{
    double width,length;

    public Rectangle(double a,double b)
    {
        width=a;
        length=b;
    }
    @Override
    public double calculateArea() 
    {
        return width*length;
    }

    @Override
    public double calculatePerimeter() 
    {
        return 2*(width+length);
    }
    
}
